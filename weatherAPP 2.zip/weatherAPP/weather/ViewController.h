//
//  ViewController.h
//  weather
//
//  Created by Rama Kunthur on 3/29/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *country;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *condition;

@property (weak, nonatomic) IBOutlet UILabel *Winddata;
@property (weak, nonatomic) IBOutlet UILabel *pressuredata;
@property (weak, nonatomic) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

