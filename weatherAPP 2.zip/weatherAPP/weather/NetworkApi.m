//
//  NetworkApi.m
//  Location
//
//  Created by Raja Sinha on 07/05/15.
//  Copyright (c) 2015 Location. All rights reserved.
//

#import "NetworkApi.h"


@interface NetworkApi()

@property(strong,nonatomic)NSURLSession *session;

@end


static NSString *kLogFileName = @"NetworkAPICalls";

@implementation NetworkApi

+ (instancetype)sharedInstance
{
static NetworkApi *sharedInstance = nil;
static dispatch_once_t onceToken;
dispatch_once(&onceToken, ^{
sharedInstance = [[NetworkApi alloc] init];
});
return sharedInstance;
}




- (void)executePostRequestWithURLString:(NSString *)urlString
              parameter:(id)parameter
            contentType:(NSString *)contentType
        callbackHandler:(callbackHandler)block
{
   
    NSError *error;
    
    // configuring urlsession
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    NSURLSession *session = [NSURLSession sessionWithConfiguration:configuration delegate:self delegateQueue:nil];
 
    NSURL *url = [NSURL URLWithString:urlString];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:60.0];
    
    [request addValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [request addValue:@"application/json" forHTTPHeaderField:@"Accept"];
    
    [request setHTTPMethod:@"GET"];
    
    NSURLSessionDataTask *postDataTask = [session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        //nsserialisation and getting data into dictionary
        
        NSDictionary *dict =[NSJSONSerialization JSONObjectWithData:data options:nil error:nil];
        block(nil,dict);
    }];
    
    [postDataTask resume];
        }



@end
