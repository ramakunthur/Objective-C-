//
//  main.m
//  weather
//
//  Created by Rama Kunthur on 3/29/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
