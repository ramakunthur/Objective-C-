//
//  WeatherData.m
//  weather
//
//  Created by intel on 31/03/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import "WeatherData.h"

@implementation WeatherData

-(id)initwithdata:(NSDictionary *)weatherdata
{
    //assining icon into stringformat or assigning objects values into string format
    self.country=weatherdata[@"sys"][@"country"];
    self.place=weatherdata[@"name"];
    self.pressure=weatherdata[@"main"][@"pressure"];
    self.windspeed=weatherdata[@"wind"][@"speed"];
    self.weatherCondition=[weatherdata[@"weather"] objectAtIndex:0][@"main"];
    self.icon=[weatherdata[@"weather"] objectAtIndex:0][@"icon"];
    return self;
}
@end
