//
//  AppDelegate.h
//  weather
//
//  Created by Rama Kunthur on 3/29/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

