//
//  WeatherData.h
//  weather
//
//  Created by intel on 31/03/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WeatherData : NSObject
@property(nonatomic,strong)NSString *country;
@property(nonatomic,strong)NSString *place;
@property(nonatomic,strong)NSString *pressure;
@property(nonatomic,strong)NSString *windspeed;
@property(nonatomic,strong)NSString *icon;
@property(nonatomic,strong)NSString *weatherCondition;
-(id)initwithdata:(NSDictionary *)weatherdata;
@end
