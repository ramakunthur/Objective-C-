//
//  ViewController.m
//  weather
//
//  Created by Rama Kunthur on 3/29/17.
//  Copyright © 2017 Rama Kunthur. All rights reserved.
//

#import "ViewController.h"
#import "NetworkApi.h"
#import "WeatherData.h"
@interface ViewController ()
//@property(strong,nonatomic) NSMutableArray *dataArray;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.activityIndicator startAnimating];
    
    NetworkApi *apiCall=[NetworkApi sharedInstance];
    [apiCall executePostRequestWithURLString:@"http://api.openweathermap.org/data/2.5/weather?q=Westervile,oh,us&APPID=2bc91140cb5c907e752bc3f027e2472b" parameter:nil contentType:@"application/json" callbackHandler:^(NSError *error, id response) {
        [self.activityIndicator stopAnimating];
        self.activityIndicator.hidden=NO;
        WeatherData *postdata=[[WeatherData alloc]initwithdata:response];
        
        dispatch_async(dispatch_get_main_queue(), ^{
        
            
            self.imageView.image=[self getImage:postdata.icon];
            self.country.text=[NSString stringWithFormat:@"%@/%@",postdata.country,postdata.place];
            self.condition.text=postdata.weatherCondition;
            self.pressuredata.text=[NSString stringWithFormat:@"%@mb",postdata.pressure];
            self.Winddata.text=[NSString stringWithFormat:@"%@km/h E",postdata.windspeed];
            
        });
        
    }];
   }
// for getting imageview url

-(UIImage*)getImage:(NSString*)icon
{
    
    UIImage* myImage = [UIImage imageWithData:
                        [NSData dataWithContentsOfURL:
                         [NSURL URLWithString: [NSString stringWithFormat:@"http://openweathermap.org/img/w/%@.png",icon]]]];
    
    
    return myImage;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
